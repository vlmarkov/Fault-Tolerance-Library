/*
 * Copyright (c) 2010-2012 Oak Ridge National Labs.  All rights reserved.
 * Copyright (c) 2011-2015 The University of Tennessee and The University
 *                         of Tennessee Research Foundation.  All rights
 *                         reserved.
 *
 *
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */
#include "orte/util/name_fns.h"
#include "orte/runtime/orte_globals.h"

#include "ompi/runtime/params.h"
#include "ompi/communicator/communicator.h"
#include "ompi/mca/pml/pml.h"

static int ompi_comm_revoke_local(ompi_communicator_t* comm,
                                  ompi_comm_rbcast_message_t* msg);

static int comm_revoke_cb_type = -1;

int ompi_comm_init_revoke(void) {
    int ret;

    ret = ompi_comm_init_rbcast();
    if( ret != OMPI_SUCCESS ) return ret;

    ret = ompi_comm_rbcast_register_cb_type(ompi_comm_revoke_local);
    if( 0 <= ret ) {
        comm_revoke_cb_type = ret;
        return OMPI_SUCCESS;
    }
    return ret;
}

int ompi_comm_finalize_revoke(void) {
    int ret;
    ret = ompi_comm_rbcast_unregister_cb_type(comm_revoke_cb_type);
    comm_revoke_cb_type = -1;
    return ret;
}

/** MPI_Comm_revoke(comm)
 * uplevel call from the API to initiate a revoke
 */
int ompi_comm_revoke_internal(ompi_communicator_t* comm)
{
    int ret = OMPI_SUCCESS;;

    OPAL_OUTPUT_VERBOSE((1, ompi_ftmpi_output_handle,
                         "%s %s: Initiate a revoke on communicator %3d:%d",
                         ORTE_NAME_PRINT(ORTE_PROC_MY_NAME), __func__, comm->c_contextid, comm->c_epoch ));

    /* Mark locally revoked */
    if( ompi_comm_revoke_local(comm, NULL) ) {
        /* Broadcast the 'revoke' signal to all other processes. */
        ompi_comm_rbcast_message_t msg;
        msg.cid   = comm->c_contextid;
        msg.epoch = comm->c_epoch;
        msg.type  = comm_revoke_cb_type;
        ret = ompi_comm_rbcast(comm, &msg, sizeof(msg));
    }
    return ret;
}


/* internal code to revoke the communicator structure. Can be called from the
 * API or from receiving a revoke message */
static int ompi_comm_revoke_local(ompi_communicator_t* comm, ompi_comm_rbcast_message_t* msg) {
    if( comm->comm_revoked ) {
        OPAL_OUTPUT_VERBOSE((9, ompi_ftmpi_output_handle,
                "%s %s: comm %3d:%d is already revoked, nothing to do",
                ORTE_NAME_PRINT(ORTE_PROC_MY_NAME), __func__, comm->c_contextid, comm->c_epoch));
        return false;
    }
    OPAL_OUTPUT_VERBOSE((9, ompi_ftmpi_output_handle,
            "%s %s: comm %3d:%d is marked revoked locally",
            ORTE_NAME_PRINT(ORTE_PROC_MY_NAME), __func__, comm->c_contextid, comm->c_epoch));
    /*
     * Locally revoke the communicator
     *
     * Just to be pedantic, as the 'revoke' condition is checked first
     * by all other communication,
     * - Turn off collectives
     * - Turn off ANY_SOURCE receives
     */
    comm->any_source_enabled        = false;
    /* purge the communicator unexpected fragments and matching logic */
    MCA_PML_CALL(revoke_comm(comm, false));
    /* Signal the point-to-point stack to recheck requests */
    OPAL_THREAD_LOCK(&ompi_request_lock);
    opal_condition_signal(&ompi_request_cond);
    OPAL_THREAD_UNLOCK(&ompi_request_lock);
    return true;
}

